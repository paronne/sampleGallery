# svyChartJS
Servoy Chart.js library. The library contains two flavours of the Chart.js libabry found at: http://www.chartjs.org/
